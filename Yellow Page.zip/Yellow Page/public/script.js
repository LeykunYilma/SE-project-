$(function () {
    let root = document.getElementById("root");
    root.innerHTML = getIndex();
    let searchBar = document.getElementById("searchBar");
    $("#searchBar").on("keyup", handleSearchBar);
    let links = document.getElementsByClassName("nav-items");
    for(let i = 0; i < links.length; i++){
        let a = links[i];
        a.onclick = function() {
            for (let j = 0; j < links.length; j++) {
                let b = links[j];
                b.style.backgroundColor = "black";
                b.style.color = "#CCC";
            }
            a.style.backgroundColor = "#CCC";
            a.style.color = "black";
            if(this.id == "home") {
                root.innerHTML = getIndex();
                $("#searchBar").on("keyup", handleSearchBar);
            } else if(this.id == "add") {
                root.innerHTML = getAddEditTemplate("addEditWord('add')", "Add");
            } else if(this.id == "edit") {
                root.innerHTML = getAddEditTemplate("addEditWord('edit')", "Save");
            } else if(this.id == "register"){
                registerLoginTemplate("register()", "Sign Up");
            } else if(this.id == "login") {
                registerLoginTemplate("login()", "Sign In");
            }
            return true;
        }
    }
});

function handleSearchBar(e) {
    if (e.keyCode == 13)
        getMeaning();
    else
        getSuggestion();
}

function getMeaning() {
    $("#meaning").load("/dictionary?word=" + document.getElementById("searchBar").value.trim());
}

function getSuggestion() {
    document.getElementById("meaning").innerHTML = "";
    $("#suggestion").load("/suggestion?prefix=" + document.getElementById("searchBar").value.trim());
}

function getEventTarget(e) {
    e = e || window.event;
    return e.target || e.srcElement;
}

function autoComplete(event) {
    document.getElementById("searchBar").value = getEventTarget(event).innerHTML;
    document.getElementById("suggestion").innerHTML = "";
    getMeaning();
}

function addEditWord(command) {
    let word = document.getElementById("firstBar").value.trim();
    let meaning = document.getElementById("secondBar").value.trim();
    $.get("/" + command + "?word=" + word + "&meaning=" + meaning, function (msg) {
        displayMessage(msg);
    });
}

function login() {
    let username = document.getElementById("firstBar").value.trim();
    let password = document.getElementById("secondBar").value.trim();
    let token = (function () {
        let t = "";
        for (i = 0; i < username.length; i++) {
            for (j = 0; j <= i; j++) {
                t += username[i];
            }
        }
        return t;
    })();

    $.post("/login", {"username": username, "password": password, "token": token}, function (msg) {
        if (msg == "Successfully logged in")
            document.getElementById("add").onclick();
        else
            displayMessage(msg);
    });
}

function register() {
    let username = document.getElementById("firstBar").value.trim();
    let password = document.getElementById("secondBar").value.trim();
    $.post("/register", {"username": username, "password": password}, function (msg) {
        if (msg == "Successfully registered")
            document.getElementById("login").onclick();
        else
            displayMessage(msg);
    });
}

function getIndex() {
    return `<input class="form-control" id="searchBar" name="word" type="text" autocomplete="off" placeholder="Search for Contact" />
			    <div id = "suggestion" onclick="autoComplete()"></div>
			    <div id="meaning" class="container"></div>`;
}

function getAddEditTemplate(command, btnText) {
    return `<form>
			        <label for="firstBar">Contact Name: </label>
			        <input id="firstBar" class="form-control" name="firstBar" autocomplete="off" type="text" />
			        <label for="secondBar">Phone Number: </label>
			        <input id="secondBar" class="form-control" name="secondBar" autocomplete="off" type="text" />
		            <div id="notify" style="visibility: hidden;">Successfully added</div>
					<button id="btn" class="btn btn-primary" type="button" onclick=` + command + `>` + btnText + `</button>
			    </form>`;
}

function registerLoginTemplate(command, btnText) {
    document.getElementById("root").innerHTML = getAddEditTemplate(command, btnText);
    document.getElementsByTagName("label")[0].innerHTML = "Username: ";
    document.getElementsByTagName("label")[1].innerHTML = "Password: ";
    document.getElementById("secondBar").type = "password";
}

function displayMessage(msg) {
    let notify = document.getElementById("notify");
    notify.innerHTML = msg;
    notify.style.visibility = "visible";
    setTimeout(function() {
        notify.style.visibility = "hidden";
    }, 2000);
}
