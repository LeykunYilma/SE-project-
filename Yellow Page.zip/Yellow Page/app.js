let express = require("express");
let app = express();
let bodyParser = require("body-parser");
let fs = require("fs");
let dictionary = require("./data/words.json");
let users = require("./data/users.json");
let tokens = require("./data/tokens.json");
const PORT = 3000;

app.use(express.static("public"));
app.use(bodyParser.urlencoded({extended: true}));

let authenticate = function(req, res, next) {
    //let token = req.query.token;
    if (tokens["token"])
        next();
    else
        res.send("You need to login to access this functionality");
}

app.get("/dictionary", function(req, res) {
    let word = req.query["word"].toUpperCase();
    if (!word) {
        res.send("Please enter the contact name");
        return;
    }
    if (word in dictionary) {
        res.send(word + ":<br/>" + dictionary[word]);
    } else {
        res.send(word + " not found.");
    }
});

app.get("/suggestion", function (req, res) {
    let prefix = req.query["prefix"].toUpperCase();
    let counter = 0;
    let suggestedWords = "";
    for (let word in dictionary) {
        if (!prefix)
            break;
        if (counter <= 5) {
            if(word.startsWith(prefix)){
                suggestedWords += "<li class='suggestion'>" + word + "</li>";
                counter++;
            }
        } else break;
    }
    res.send(suggestedWords);
});

function addEditHandler(req, res, command, msg, a, b) {
    let word = req.query["word"].toUpperCase();
    let meaning = req.query["meaning"];
    if (word) {
        if (a*(word in dictionary) + b) {
            if (!meaning) {
                res.send("Please enter phone number");
                return;
            }
            dictionary[word] = meaning;
            fs.writeFile("./data/words.json", JSON.stringify(dictionary), function(err){
                if(err){
                    res.send("Unable to " + command + " contact Name");
                    return;
                }
                res.send("Contact successfully " + command + "ed");
            });
        } else{
            res.send(msg);
        }
    } else {
        res.send("Please enter contact Name");
    }
}

app.get("/add", authenticate, function(req, res){
    addEditHandler(req, res, "add", "Can't add an already existing Contact Name", -1, 1);
});

app.get("/edit", authenticate, function(req, res) {
    addEditHandler(req, res, "edit", "Contact not found", 1, 0);
});

app.post("/register", function(req, res){
    let username = req.body["username"];
    let password = req.body["password"];
    if (username && password){
        if (!(username in users)) {
            users[username] = password;
            fs.writeFile("./data/users.json", JSON.stringify(users), function (err) {
                if (err) {
                    res.send("Unable to register");
                } else {
                    res.send("Successfully registered");
                }
            });
        } else {
            res.send("Username already taken");
        }
    } else{
        res.send("Please enter username and password");
    }
});

app.post("/login", function(req, res){
    let username = req.body["username"];
    let password = req.body["password"];
    let token = req.body["token"];

    if (username && password){
        if(username in users && users[username] == password) {
            tokens["token"] = token;
            fs.writeFile("./data/tokens.json", JSON.stringify(tokens), function (err) {
                if (err) {
                    res.send("Unable to login");
                } else {
                    res.send("Successfully logged in");
                }
            });
        } else {
            res.send("Incorrect username or password");
        }
    } else{
        res.send("Please enter username and password");
    }
});

app.listen(PORT, function (req, res) {
    console.log("Listening on port 3000...");
});
